from django.shortcuts import render

# Create your views here.
def home(request):
    context = {}
    return render(request, 'myapp1/home.html', context)